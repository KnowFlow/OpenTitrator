# -*- coding: utf-8 -*-

from pinpong.board import Board,Pin,ADC
from pinpong.libs.dfrobot_urm09 import URM09
from pinpong.libs.kamoer_4460 import STEP_DRIVER_4460
from pinpong.libs.dfrobot_ph import DFRobot_PH

win=Board("win").begin()
leo = Board("leonardo").begin()

acidpump = STEP_DRIVER_4460(board=win, port="com6", addr = 0xC0)
alkalipump = STEP_DRIVER_4460(board=win, port="com6", addr = 0xC1)
testpump = STEP_DRIVER_4460(board=win, port="com6", addr = 0xC2) 

urm = URM09(board=leo, i2c_addr=0x11) #初始化传感器，设置I2C地址
urm.set_mode_range(urm._MEASURE_MODE_AUTOMATIC ,urm._MEASURE_RANG_150)

pwm0 = Pin(board=leo, pin=Pin.D8, mode=Pin.OUT)
pwm1 = Pin(board=leo, pin=Pin.D9, mode=Pin.OUT)

ph_meter = DFRobot_PH(board=leo,adc=ADC(board=leo,pin_obj=Pin(board=leo,pin=Pin.A0)))

dist = urm.distance_cm()
default_dist = 10
flowrate = 5
target_ph = 7
current_pump=None
duration_per_10ml = 334.6/3*2 #速度为10
factor = 2 #比例系数
test_liquide_volume = 10 #被测液体的体积10ml

acid_concentration = 0.10 #0.10 mol/L
alkali_concentration = 0.1 #0.020 mol/L
