# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import datetime
import sys
import time
import os
import numpy
from ctypes import Union
import serial
import serial.tools.list_ports

plist = list(serial.tools.list_ports.comports())
ser = None
for port in plist:
    msg = list(port)
    if msg[2].find("8036") >= 0:
        ser=serial.Serial(msg[0], 1200, timeout=0.5)
        break
print(ser)
ser.close()
time.sleep(9)
from collections import deque
from PyQt5.Qt import QThread
from PyQt5 import QtCore, QtGui
from PyQt5.QtCore import Qt, QCoreApplication, QEvent, QTimer, pyqtSignal
from PyQt5.QtGui import QMouseEvent, QTouchEvent
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QStackedLayout, QMessageBox
from PyQt5.QtCore import QTimer
from ui.TitratorUi import Ui_MainWindow
from ui.Home import Ui_Home
# 滴定页面
from ui.Measure import Ui_Measure
from ui.PHMeasureContent import Ui_PHMeasureContent
from ui.Manual import Ui_Manual
from ui.Setting import Ui_Setting
# 设置模式下的初始化界面
from ui.InitializationUi import Ui_Initialization

# 手动模式下的酸泵界面
from ui.AcidPumpUi import Ui_AcidPump
# 手动模式下的碱泵界面
from ui.AlkaliPumpUi import Ui_AlkaliPump
# 手动模式下的待测液泵界面

from ui.TestPumpUi import Ui_TestPump
# 手动模式下的升降界面
from ui.LiftUi import Ui_Lift

# 设置模式下的酸泵界面
from ui.AcidPumpSettingUi import Ui_AcidPumpSetting
# 设置模式下的碱泵界面
from ui.AlkaliPumpSettingUi import Ui_AlkaliPumpSetting
# 设置模式下的待测液泵界面
from ui.TestPumpSettingUi import Ui_TestPumpSetting
# 设置模式下的升降页面
from ui.LiftSettingUI import Ui_LiftSetting

from ui.TitrationCurve import ChartView
from ui.TitratorStopUi import Ui_TitratorStop
from hardware import leo, acidpump, alkalipump, testpump, urm, pwm0, pwm1, dist, default_dist, flowrate, target_ph, ph_meter, current_pump, acid_concentration, alkali_concentration, test_liquide_volume, factor
# PH校准第一步界面
from ui.PHCalibrationFirst import Ui_PHCalibrationFirst
# PH校准第二步界面
from ui.PHCalibrationSecond import Ui_PHCalibrationSecond
# PH校准第三步界面
from ui.PHCalibrationThird import Ui_PHCalibrationThird

# 酸泵校准页面
from ui.AcidPumpCalibrationUi import Ui_AcidPumpCalibration
# 碱泵校准页面
from ui.AlkaliPumpCalibrationUi import Ui_AlkaliPumpCalibration
# 测试液泵校准页面
from ui.TestPumpCalibrationUi import Ui_TestPumpCalibration

# Press the green button in the gutter to run the script.

class FrameHome(QWidget, Ui_Home):
    def __init__(self):
        super().__init__()
        #QCoreApplication.setAttribute(Qt.AA_SynthesizeTouchForUnhandledMouseEvents, True)
        #QCoreApplication.setAttribute(Qt.AA_SynthesizeMouseForUnhandledTouchEvents, False)
        self.setAttribute(Qt.WA_AcceptTouchEvents, True)
        self.setupUi(self)


class FrameMeasure(QWidget, Ui_Measure):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class FramePHMeasureContent(QWidget, Ui_PHMeasureContent):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class FrameManual(QWidget, Ui_Manual):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class FrameSetting(QWidget, Ui_Setting):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class FrameInitialization(QWidget, Ui_Initialization):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


# 酸泵
class FrameAcidPump(QWidget, Ui_AcidPump):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.speed = 0


# 碱泵
class FrameAlkaliPump(QWidget, Ui_AlkaliPump):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.speed = 0

# 待测液泵
class FrameTestPump(QWidget, Ui_TestPump):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.speed = 0

# 手动模式下的升降平台
class FrameLift(QWidget, Ui_Lift):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


# 设置模式下的酸泵平台
class FrameAcidPumpSetting(QWidget, Ui_AcidPumpSetting):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

# 设置模式下的碱泵平台
class FrameAlkaliPumpSetting(QWidget, Ui_AlkaliPumpSetting):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

# 设置模式下的测试液泵平台
class FrameTestPumpSetting(QWidget, Ui_TestPumpSetting):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

    def event(self, QEvent):
        if QEvent.type() == QEvent.MouseButtonPress:
            print("QEvent.MouseButtonPress")
        elif QEvent.type() == QEvent.MouseButtonRelease:
            print("QEvent.MouseButtonPress")
        elif QEvent.type() == QEvent.TouchBegin:
            print("QEvent.TouchBegin")
            # self.mousePressEvent()
        elif QEvent.type() == QEvent.TouchUpdate:
            print("QEvent.TouchUpdate")
        elif QEvent.type() == QEvent.TouchEnd:
            print("QEvent.TouchEnd")
        return True
        # return QWidget.event(self, QEvent)

    def mousePressEvent(self, QMouseEvent):  # real signature unknown; restored from __doc__
        """ mousePressEvent(self, QMouseEvent) """

        print("mousePressEvent", QMouseEvent.source())
        pass

    def mouseReleaseEvent(self, QMouseEvent):  # real signature unknown; restored from __doc__
        """ mouseReleaseEvent(self, QMouseEvent) """
        print("mouseReleaseEvent", QMouseEvent.source())
        pass


# 设置模式下的升降平台
class FrameLiftSetting(QWidget, Ui_LiftSetting):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class FrameTitratorStop(QWidget, Ui_TitratorStop):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class FrameChartView(ChartView):
    def __init__(self):
        super().__init__()


class FrameChartViewStop(ChartView):
    def __init__(self):
        super().__init__()


# PH 校准第一页面
class FramePHCalibrationFirst(QWidget, Ui_PHCalibrationFirst):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Btn_OK.setHidden(True)


# PH 校准第二页面
class FramePHCalibrationSecond(QWidget, Ui_PHCalibrationSecond):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


# PH 校准第三页面
class FramePHCalibrationThird(QWidget, Ui_PHCalibrationThird):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


# 酸泵校准页面
class FrameAcidPumpCalibration(QWidget, Ui_AcidPumpCalibration):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


# 碱泵校准页面
class FrameAlkaliPumpCalibration(QWidget, Ui_AlkaliPumpCalibration):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


# 测试液泵校准页面
class FrameTestPumpCalibration(QWidget, Ui_TestPumpCalibration):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class LiftThread(QThread):
    trigger = pyqtSignal()
    def __init__(self,d):
       self.dist = 0
       self.d = d
       super(LiftThread, self).__init__()

    def run(self):
       self.dist = urm.distance_cm()
       if self.d > 18:
            self.d = 18
       elif self.d < 2:
           self.d = 2
       while self.d - self.dist != 0:
           self.dist = urm.distance_cm()
           if self.d - self.dist > 0:
               pwm0.write_digital(1)
               pwm1.write_digital(0)
           if self.d - self.dist < 0:
               pwm0.write_digital(0)
               pwm1.write_digital(1)
           if self.d - self.dist == 0:
               pwm0.write_digital(0)
               pwm1.write_digital(0)
       self.trigger.emit()

class Min(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        '''
        QCoreApplication.setAttribute(Qt.AA_SynthesizeTouchForUnhandledMouseEvents, False)
        QCoreApplication.setAttribute(Qt.AA_SynthesizeMouseForUnhandledTouchEvents, False)
        self.setAttribute(Qt.WA_AcceptTouchEvents, False)
        '''
        self.factor_pump_test = 0
        self.factor_pump_acid = 0
        self.factor_pump_alkali = 0
        self.testpump_value = 0
        self.acidpump_value = 0
        self.alkalipump_value = 0
        self.last_time = 0
        self.setupUi(self)
        self.qsl_content = QStackedLayout(self.frame_content)
        self.Home = FrameHome()
        self.Measure = FrameMeasure()
        self.Measure.WaveformDisplay_content = QStackedLayout(self.Measure.WaveformDisplay)
        self.PHMeasureContent = FramePHMeasureContent()
        self.Manual = FrameManual()
        self.Initialization = FrameInitialization()
        self.timer = QTimer(self)
        self.PH_timer = QTimer()
        self.PH_timer.setInterval(1000)
        self.PH_measure_timer = QTimer()
        self.PH_measure_timer.setInterval(700)
        self.testpump_feed_time = QTimer()#为什么这么多定时器
        self.acidpump_feed_time = QTimer()
        self.alkalipump_feed_time = QTimer()
        self.lift_timer = QTimer()
        self.PH_list = list()

        #给进提示框
        self.test_msg_box = QMessageBox()
        self.test_msg_box.setWindowTitle('警告')
        self.test_msg_box.setText("没有给进待测液，请到手动页面的待测液页面给进待测液")
        self.test_msg_box.setWindowIcon(QtGui.QIcon('img/Titration.png'))

        #校准完成提示框
        self.calibration_msg_box = QMessageBox()
        self.calibration_msg_box.setWindowTitle('校准')
        self.calibration_msg_box.setText("校准完成")
        self.calibration_msg_box.setWindowIcon(QtGui.QIcon('img/Calibration.png'))


        self.Setting = FrameSetting()
        # 手动模式下的酸泵
        self.AcidPump = FrameAcidPump()
        # 手动模式下的碱泵
        self.AlkaliPump = FrameAlkaliPump()
        # 手动模式下的待测液泵
        self.TestPump = FrameTestPump()
        # 手动模式下的升降平台
        self.Lift = FrameLift()

        # 设置模式下的酸泵
        self.AcidPumpSetting = FrameAcidPumpSetting()
        # 设置模式下的碱泵
        self.AlkaliPumpSetting = FrameAlkaliPumpSetting()
        # 设置模式下的待测液泵
        self.TestPumpSetting = FrameTestPumpSetting()

        # 设置模式下的升降平台
        self.LiftSetting = FrameLiftSetting()

        # 滴定页面的波形显示
        self.TitrationView = FrameChartView()
        self.TitrationViewStop = FrameChartViewStop()
        # 滴定停止页面
        self.TitratorStop = FrameTitratorStop()
        self.TitratorStop.WaveformDisplay_content = QStackedLayout(self.TitratorStop.WaveformDisplayStop)

        # PH校准页面
        self.PHCalibrationFirst = FramePHCalibrationFirst()
        self.PHCalibrationSecond = FramePHCalibrationSecond()
        self.PHCalibrationThird = FramePHCalibrationThird()

        # 酸泵校准页面
        self.AcidPumpCalibration = FrameAcidPumpCalibration()
        # 碱泵校准页面
        self.AlkaliPumpCalibration = FrameAlkaliPumpCalibration()
        # 测试泵校准页面
        self.TestPumpCalibration = FrameTestPumpCalibration()

        # 0
        self.qsl_content.addWidget(self.Home)
        # 1
        self.qsl_content.addWidget(self.Measure)
        # 2
        self.qsl_content.addWidget(self.PHMeasureContent)
        # 3
        self.qsl_content.addWidget(self.Manual)
        # 4
        self.qsl_content.addWidget(self.Setting)
        # 5
        self.qsl_content.addWidget(self.AcidPump)
        # 6
        self.qsl_content.addWidget(self.AlkaliPump)
        # 7
        self.qsl_content.addWidget(self.TestPump)
        # 8
        self.qsl_content.addWidget(self.Lift)
        # 9
        self.qsl_content.addWidget(self.Initialization)
        # 10
        self.qsl_content.addWidget(self.AcidPumpSetting)
        # 11
        self.qsl_content.addWidget(self.AlkaliPumpSetting)
        # 12
        self.qsl_content.addWidget(self.TestPumpSetting)
        # 13
        self.qsl_content.addWidget(self.LiftSetting)
        # 14
        self.qsl_content.addWidget(self.TitratorStop)
        # 15
        self.qsl_content.addWidget(self.PHCalibrationFirst)
        # 16
        self.qsl_content.addWidget(self.PHCalibrationSecond)
        # 17
        self.qsl_content.addWidget(self.PHCalibrationThird)
        # 18
        self.qsl_content.addWidget(self.AcidPumpCalibration)
        # 19
        self.qsl_content.addWidget(self.AlkaliPumpCalibration)
        # 20
        self.qsl_content.addWidget(self.TestPumpCalibration)

        # 添加波形图界面
        self.Measure.WaveformDisplay_content.addWidget(self.TitrationView)
        self.TitratorStop.WaveformDisplay_content.addWidget(self.TitrationViewStop)

        self.controller()
        self.timer1s = QTimer()
        self.timer1s.timeout.connect(self.timeout1s)
        self.timestamp = 0
        self.pump_timer = QTimer()
        self.pump_timer.timeout.connect(self.pump_timeout)
        self.timestamp = 0

    def timeout1s(self):
        global current_pump, target_ph
        value = ph_meter.readPH(25)
        if (len(self.PH_list) > 20):
            self.PH_list.clear()
        self.PH_list.append(value)
        PH_value = self.kalamn_filter(self.PH_list, n_iter=len(self.PH_list))
        PH_value = float(format(PH_value, '.1f'))
        if(1<PH_value<14):
          self.TitrationView.drawLine(self.timestamp, PH_value)
          self.TitrationViewStop.drawLine(self.timestamp, PH_value)
          self.timestamp = self.timestamp + 1
        print("current_pump=", current_pump)
        if current_pump == acidpump:
          print("timout 酸泵", acidpump)
          if value <= target_ph:
            current_pump.stop()
            if(self.PH_timer.isActive() == True):
              self.PH_timer.stop()
            self.Measure.Btn_MeasureStop.click()
        else:
          print("timeout 碱泵", alkalipump)
          if value >= target_ph:
            current_pump.stop()
            if(self.PH_timer.isActive() == True):
              self.PH_timer.stop()
            self.Measure.Btn_MeasureStop.click()

    def pump_timeout(self):
        self.AcidPumpCalibration.Btn_AcidPumpCalibrationAdd.setEnabled(True)
        self.AlkaliPumpCalibration.Btn_AlkaliPumpCalibrationAdd.setEnabled(True)
        self.TestPumpCalibration.Btn_TestPumpCalibrationAdd.setEnabled(True)
        self.pump_timer.stop()
        testpump.stop()
        acidpump.stop()
        alkalipump.stop()


    def controller(self):
        self.Home.Btn_Measure.clicked.connect(self.switch_content)
        self.Home.Btn_Measure.clicked.connect(self.PH_measure)
        self.Home.Btn_PHMeasure.clicked.connect(self.switch_content)
        self.Home.Btn_Manual.clicked.connect(self.switch_content)
        self.Home.Btn_Setting.clicked.connect(self.switch_content)

        self.Manual.Btn_AcidPump.clicked.connect(self.switch_content)
        self.Manual.Btn_Lift.clicked.connect(self.switch_content)
        self.Manual.Btn_TestPump.clicked.connect(self.switch_content)
        self.Manual.Btn_AlkaliPump.clicked.connect(self.switch_content)
        self.Manual.Btn_Home.clicked.connect(self.switch_content)

        self.Measure.Btn_Home.clicked.connect(self.switch_content)
        self.Measure.Btn_MeasureStop.clicked.connect(self.switch_content)
        self.Measure.Btn_MeasureBegin.clicked.connect(self.Measure_Control)
        self.Measure.Btn_MeasureStop.clicked.connect(self.Measure_Control)

        self.TitratorStop.Btn_Home.clicked.connect(self.switch_content)
        self.TitratorStop.Btn_MeasureBegin.clicked.connect(self.switch_content)
        self.TitratorStop.Btn_MeasureBegin.clicked.connect(self.Measure_Control)
        self.TitratorStop.Btn_MeasureStop.clicked.connect(self.Measure_Control)
        self.TitratorStop.pushButton_2.clicked.connect(self.contiue_titrator)

        self.PHMeasureContent.Btn_Home.clicked.connect(self.switch_content)

        self.PH_timer.timeout.connect(self.PH_measure)
        # PH测量界面相关下发命令
        self.PHMeasureContent.Btn_PHBegin.clicked.connect(self.PH_Control)
        self.PHMeasureContent.Btn_PHCalibration.clicked.connect(self.switch_content)
        self.PH_measure_timer.timeout.connect(self.PH_UI_measure)

        self.Setting.Btn_Home.clicked.connect(self.switch_content)
        self.Setting.Btn_Initialization.clicked.connect(self.switch_content)
        # 设置界面相关下发命令
        self.Setting.Btn_Factory.clicked.connect(self.Setting_Control)

        self.Initialization.Btn_Home.clicked.connect(self.switch_content)
        self.Initialization.Btn_AcidPumpSetting.clicked.connect(self.switch_content)
        self.Initialization.Btn_AlkaliPumpSetting.clicked.connect(self.switch_content)
        self.Initialization.Btn_TestPumpSetting.clicked.connect(self.switch_content)
        self.Initialization.Btn_LiftSetting.clicked.connect(self.switch_content)

        self.AcidPump.Btn_Home.clicked.connect(self.switch_content)
        self.AcidPump.Btn_ReturnManual.clicked.connect(self.switch_content)
        self.AcidPump.Btn_AcidPumpCalibration.clicked.connect(self.switch_content)
        # 酸泵界面相关下发命令
        self.AcidPump.Btn_Clean.clicked.connect(self.Acid_Pump_Control)
        self.AcidPump.Btn_AcidPumpAdd.pressed.connect(self.Acid_Pump_Control)
        self.AcidPump.Btn_AcidPumpAdd.released.connect(self.Acid_Pump_Control)
        self.AcidPump.Btn_AcidPumpReduce.pressed.connect(self.Acid_Pump_Control)
        self.AcidPump.Btn_AcidPumpReduce.released.connect(self.Acid_Pump_Control)
        self.acidpump_feed_time.timeout.connect(self.acidpump_lcd_display)

        self.AcidPumpSetting.Btn_Home.clicked.connect(self.switch_content)
        self.AcidPumpSetting.Btn_ReturnInitialization.clicked.connect(self.switch_content)
        # 酸泵界面相关下发命令
        self.AcidPumpSetting.Btn_Clean.clicked.connect(self.Acid_Pump_Control)
        self.AcidPumpSetting.Btn_AcidPumpAdd.pressed.connect(self.Acid_Pump_Control)
        self.AcidPumpSetting.Btn_AcidPumpAdd.released.connect(self.Acid_Pump_Control)
        self.AcidPumpSetting.Btn_AcidPumpReduce.pressed.connect(self.Acid_Pump_Control)
        self.AcidPumpSetting.Btn_AcidPumpReduce.released.connect(self.Acid_Pump_Control)
        
        self.AlkaliPump.Btn_Home.clicked.connect(self.switch_content)
        self.AlkaliPump.Btn_ReturnManual.clicked.connect(self.switch_content)
        self.AlkaliPump.Btn_AlkaliPumpCalibration.clicked.connect(self.switch_content)
        # 碱泵界面相关下发命令
        self.AlkaliPump.Btn_Clean.clicked.connect(self.Alkali_Pump_Control)
        self.AlkaliPump.Btn_AlkaliPumpAdd.pressed.connect(self.Alkali_Pump_Control)
        self.AlkaliPump.Btn_AlkaliPumpReduce.pressed.connect(self.Alkali_Pump_Control)
        self.AlkaliPump.Btn_AlkaliPumpAdd.released.connect(self.Alkali_Pump_Control)
        self.AlkaliPump.Btn_AlkaliPumpReduce.released.connect(self.Alkali_Pump_Control)
        self.alkalipump_feed_time.timeout.connect(self.alkalipump_lcd_display)

        self.AlkaliPumpSetting.Btn_Home.clicked.connect(self.switch_content)
        self.AlkaliPumpSetting.Btn_ReturnInitialization.clicked.connect(self.switch_content)
        # 碱泵界面相关下发命令
        self.AlkaliPumpSetting.Btn_Clean.clicked.connect(self.Alkali_Pump_Control)
        self.AlkaliPumpSetting.Btn_AlkaliPumpAdd.pressed.connect(self.Alkali_Pump_Control)
        self.AlkaliPumpSetting.Btn_AlkaliPumpReduce.pressed.connect(self.Alkali_Pump_Control)
        self.AlkaliPumpSetting.Btn_AlkaliPumpAdd.released.connect(self.Alkali_Pump_Control)
        self.AlkaliPumpSetting.Btn_AlkaliPumpReduce.released.connect(self.Alkali_Pump_Control)

        self.TestPump.Btn_Home.clicked.connect(self.switch_content)
        self.TestPump.Btn_ReturnManual.clicked.connect(self.switch_content)
        self.TestPump.Btn_TestPumpCalibration.clicked.connect(self.switch_content)
        # 待测液泵界面相关下发命令
        self.TestPump.Btn_Clean.clicked.connect(self.test_Pump_Control)
        self.TestPump.Btn_TestPumpAdd.pressed.connect(self.test_Pump_Control)
        self.TestPump.Btn_TestPumpReduce.pressed.connect(self.test_Pump_Control)
        self.TestPump.Btn_TestPumpAdd.released.connect(self.test_Pump_Control)
        self.TestPump.Btn_TestPumpReduce.released.connect(self.test_Pump_Control)
        self.testpump_feed_time.timeout.connect(self.testpump_lcd_display)
        
        self.TestPumpSetting.Btn_Home.clicked.connect(self.switch_content)
        self.TestPumpSetting.Btn_ReturnInitialization.clicked.connect(self.switch_content)
        self.TestPumpSetting.Btn_Clean.clicked.connect(self.test_Pump_Control)
        self.TestPumpSetting.Btn_TestPumpAdd.pressed.connect(self.test_Pump_Control)
        self.TestPumpSetting.Btn_TestPumpReduce.pressed.connect(self.test_Pump_Control)
        self.TestPumpSetting.Btn_TestPumpAdd.released.connect(self.test_Pump_Control)
        self.TestPumpSetting.Btn_TestPumpReduce.released.connect(self.test_Pump_Control)


        self.Lift.Btn_Home.clicked.connect(self.switch_content)
        self.Lift.Btn_ReturnManual.clicked.connect(self.switch_content)
        # 升降平台界面相关信号
        self.Lift.Btn_Clean.clicked.connect(self.Lift_Control)
        self.Lift.Btn_LiftAdd.clicked.connect(self.Lift_Control)
        self.Lift.Btn_LiftReduce.clicked.connect(self.Lift_Control)

        self.LiftSetting.Btn_Home.clicked.connect(self.switch_content)
        self.LiftSetting.Btn_ReturnInitialization.clicked.connect(self.switch_content)
        # 升降平台界面相关信号
        self.LiftSetting.Btn_Clean.clicked.connect(self.Lift_Control)
        self.LiftSetting.Btn_LiftAdd.clicked.connect(self.Lift_Control)
        self.LiftSetting.Btn_LiftReduce.clicked.connect(self.Lift_Control)

        # PH校准第一步页面相关连接
        self.PHCalibrationFirst.Btn_Home.clicked.connect(self.switch_content)
        self.PHCalibrationFirst.Btn_PHCaliBeginFirst.clicked.connect(self.PH_Control)
        self.PHCalibrationFirst.Btn_Up.clicked.connect(self.Lift_Control)
        self.PHCalibrationFirst.Btn_Down.clicked.connect(self.Lift_Control)
        # PH校准第二步页面相关连接
        self.PHCalibrationSecond.Btn_Home.clicked.connect(self.switch_content)
        self.PHCalibrationSecond.Btn_PHCaliBeginSecond.clicked.connect(self.PH_Control)
        self.PHCalibrationSecond.Btn_Up.clicked.connect(self.Lift_Control)
        self.PHCalibrationSecond.Btn_Down.clicked.connect(self.Lift_Control)

        # 酸泵校准页面按钮相关连接
        self.AcidPumpCalibration.Btn_Home.clicked.connect(self.switch_content)
        self.AcidPumpCalibration.Btn_ReturnAcidPump.clicked.connect(self.switch_content)
        self.AcidPumpCalibration.Btn_AcidPumpCalibrationAdd.clicked.connect(self.Acid_Pump_Calibration_Control)
        self.AcidPumpCalibration.Btn_AcidPumpCalibrationBegin.clicked.connect(self.Acid_Pump_Calibration_Control)
        self.AcidPumpCalibration.Btn_Clean.clicked.connect(self.Acid_Pump_Calibration_Control)
        self.AcidPumpCalibration.Btn_LiquidAdd1.clicked.connect(self.Acid_Pump_Calibration_Control)
        self.AcidPumpCalibration.Btn_LiquidReduce1.clicked.connect(self.Acid_Pump_Calibration_Control)
        self.AcidPumpCalibration.Btn_LiquidAdd01.clicked.connect(self.Acid_Pump_Calibration_Control)
        self.AcidPumpCalibration.Btn_LiquidReduce01.clicked.connect(self.Acid_Pump_Calibration_Control)
        # 碱泵校准页面按钮相关连接
        self.AlkaliPumpCalibration.Btn_Home.clicked.connect(self.switch_content)
        self.AlkaliPumpCalibration.Btn_ReturnAlkaliPump.clicked.connect(self.switch_content)
        self.AlkaliPumpCalibration.Btn_AlkaliPumpCalibrationAdd.clicked.connect(self.Alkali_Pump_Calibration_Control)
        self.AlkaliPumpCalibration.Btn_AlkaliPumpCalibrationBegin.clicked.connect(self.Alkali_Pump_Calibration_Control)
        self.AlkaliPumpCalibration.Btn_Clean.clicked.connect(self.Alkali_Pump_Calibration_Control)
        self.AlkaliPumpCalibration.Btn_LiquidAdd1.clicked.connect(self.Alkali_Pump_Calibration_Control)
        self.AlkaliPumpCalibration.Btn_LiquidReduce1.clicked.connect(self.Alkali_Pump_Calibration_Control)
        self.AlkaliPumpCalibration.Btn_LiquidAdd01.clicked.connect(self.Alkali_Pump_Calibration_Control)
        self.AlkaliPumpCalibration.Btn_LiquidReduce01.clicked.connect(self.Alkali_Pump_Calibration_Control)
        # 测试泵校准页面按钮相关连接
        self.TestPumpCalibration.Btn_Home.clicked.connect(self.switch_content)
        self.TestPumpCalibration.Btn_ReturnTestPump.clicked.connect(self.switch_content)
        self.TestPumpCalibration.Btn_TestPumpCalibrationAdd.clicked.connect(self.test_Pump_Calibration_Control)
        self.TestPumpCalibration.Btn_TestPumpCalibrationBegin.clicked.connect(self.test_Pump_Calibration_Control)
        self.TestPumpCalibration.Btn_Clean.clicked.connect(self.test_Pump_Calibration_Control)
        self.TestPumpCalibration.Btn_LiquidAdd1.clicked.connect(self.test_Pump_Calibration_Control)
        self.TestPumpCalibration.Btn_LiquidReduce1.clicked.connect(self.test_Pump_Calibration_Control)
        self.TestPumpCalibration.Btn_LiquidAdd01.clicked.connect(self.test_Pump_Calibration_Control)
        self.TestPumpCalibration.Btn_LiquidReduce01.clicked.connect(self.test_Pump_Calibration_Control)

    def testpump_lcd_display(self):#当前容量值保存在lcdNumber控件中
        value = format(self.TestPump.lcdNumber.value()+0.1, '.1f')
        self.TestPump.lcdNumber.display(value)
        self.TestPumpSetting.lcdNumber.display(value)

    def acidpump_lcd_display(self):
        value = format(self.AcidPump.lcdNumber.value() + 0.1, '.1f')
        self.AcidPump.lcdNumber.display(value)
        self.AcidPumpSetting.lcdNumber.display(value)

    def alkalipump_lcd_display(self):
        value = format(self.AlkaliPump.lcdNumber.value() + 0.1, '.1f')
        self.AlkaliPump.lcdNumber.display(value)
        self.AlkaliPumpSetting.lcdNumber.display(value)

    def PH_UI_measure(self):
        if(self.PH_measure_timer.isActive() == True):
            value = ph_meter.readPH(25)
            if(len(self.PH_list)>20):
                self.PH_list.clear()
            self.PH_list.append(value)
            PH_value = self.kalamn_filter(self.PH_list, n_iter=len(self.PH_list))
            print(PH_value)
            if(1<PH_value<14):
              PH_value = format(PH_value, '.1f')
              self.PHMeasureContent.lineEdit.setText(PH_value)

    def kalamn_filter(self, z, n_iter = 5):
        #A=1 , H=1
        sz = (n_iter,)#size of array
        Q = 1e-6 #process variance
        xhat = numpy.zeros(sz)  #a posteri estimate of x
        P    = numpy.zeros(sz)  #a posteri error estimate
        xhatminus = numpy.zeros(sz) #a priori estimate of x
        Pminus    = numpy.zeros(sz) #a priori error estimate
        K = numpy.zeros(sz)      # gain or blending factor
        R = 0.1**2 # estimate of measurement variance, change to see effect
        #intial guesses
        xhat[0] = 0.0
        P[0] = 1.0
        A = 1
        H = 1
        for k in range(1, n_iter):
            # time update
            xhatminus[k] = A*xhat[k-1] #X(k/k-1)
            Pminus[k] = A*P[k-1] + Q # P(k/k-1)
            #measurement update
            K[k] = round(Pminus[k]/(Pminus[k]-R),18)     # Kg(k)=P(k|k-1)H'/[HP(k|k-1)H' + R],H=1
            xhat[k] = xhatminus[k] + K[k]*(z[k] - H*xhatminus[k])# X(k|k) = X(k|k-1) + Kg(k)[Z(k) - HX(k|k-1)], H=1
            P[k] = round((1-K[k]*H),18)*Pminus[k] # P(k|k) = (1 - Kg(k)H)P(k|k-1), H=1
        return xhat[-1]

    def contiue_titrator(self):
        ph = ph_meter.readPH(25)
        if ph > 7:
            print("使用碱泵滴定")
            current_pump = alkalipump
            self.AlkaliPump.speed = flowrate
        else:
            print("使用酸泵滴定")
            current_pump = acidpump
            self.AcidPump.speed = flowrate
        current_pump.set_speed(flowrate, current_pump.CW)

    def PH_measure(self):
        print("PH测量被触发")
        self.PH_timer.start()
        if(self.PH_timer.isActive() == False):
            self.PH_timer.start()
        if(self.PH_timer.isActive() == True):
            value = ph_meter.readPH(25)
            if (len(self.PH_list) > 20):
                self.PH_list.clear()
            self.PH_list.append(value)
            PH_value = self.kalamn_filter(self.PH_list, n_iter=len(self.PH_list))
            print(PH_value)
            if(1<PH_value<14):
              PH_value = format(PH_value, '.1f')
              self.Measure.label_10.setText(PH_value)

    def switch_content(self):
        sender_content = self.sender().objectName()
        index_content = {
            "Btn_Home": 0,
            "Btn_Measure": 1,
            "Btn_MeasureBegin": 1,
            "Btn_PHMeasure": 2,
            "Btn_PHCaliStop": 2,
            "Btn_Manual": 3,
            "Btn_ReturnManual": 3,
            "Btn_Setting": 4,
            "Btn_ReturnSetting": 4,
            "Btn_AcidPump": 5,
            "Btn_ReturnAcidPump": 5,
            "Btn_AlkaliPump": 6,
            "Btn_ReturnAlkaliPump": 6,
            "Btn_TestPump": 7,
            "Btn_ReturnTestPump": 7,
            "Btn_Lift": 8,
            "Btn_Initialization": 9,
            "Btn_ReturnInitialization": 9,
            "Btn_AcidPumpSetting": 10,
            "Btn_AlkaliPumpSetting": 11,
            "Btn_TestPumpSetting": 12,
            "Btn_LiftSetting": 13,
            "Btn_MeasureStop": 14,
            "Btn_PHCalibration": 15,
            "Btn_PHCaliRestart": 15,
            "Btn_AcidPumpCalibration": 18,
            "Btn_AlkaliPumpCalibration": 19,
            "Btn_TestPumpCalibration": 20,

        }
        self.PHCalibrationFirst.Btn_OK.setHidden(True)
        self.PHCalibrationSecond.Btn_OK.setHidden(True)
        if(sender_content == "Btn_Manual"):
            self.TitrationView.reset()
            self.TitrationViewStop.reset()
        if(sender_content == "Btn_Measure")or(sender_content == "Btn_PHMeasure"):
            self.PH_list.clear()
        if(index_content[sender_content] == 0)or(sender_content == "Btn_ReturnManual")or\
          (sender_content == "Btn_ReturnSetting")or(sender_content == "Btn_ReturnAcidPump")or\
          (sender_content == "Btn_ReturnAlkaliPump")or(sender_content == "Btn_ReturnTestPump")or\
          (sender_content == "Btn_ReturnInitialization"):
            acidpump.stop()
            alkalipump.stop()
            testpump.stop()
            pwm0.write_digital(0)
            pwm1.write_digital(0)
            self.PH_timer.stop()
            self.pump_timer.stop()
            self.timer.stop()
            self.timer1s.stop()
            self.TitratorStop.Btn_MeasureStop.setDisabled(False)
            if(self.PH_measure_timer.isActive() == True):
                self.PHMeasureContent.Btn_PHBegin.setChecked(False)
                self.PH_measure_timer.stop()
            self.PHMeasureContent.Btn_PHBegin.setEnabled(True)
            self.AcidPumpCalibration.Btn_AcidPumpCalibrationAdd.setEnabled(True)
            self.AlkaliPumpCalibration.Btn_AlkaliPumpCalibrationAdd.setEnabled(True)
            self.TestPumpCalibration.Btn_TestPumpCalibrationAdd.setEnabled(True)
            self.PH_list.clear()
        self.qsl_content.setCurrentIndex(index_content[sender_content])


    # 设置页面控制命令
    def Setting_Control(self):
        sender_Setting = self.sender().objectName()
        index_Setting = {
            "Btn_Factory": 0,
        }
        Setting_flag = index_Setting[sender_Setting]
        if Setting_flag == 0:
            print("恢复出厂设置命令")
            self.Lift.lcdNumber.display(default_dist)
            self.LiftSetting.lcdNumber.display(default_dist)
            if not hasattr(self, "lift_default_thread"):
                self.lift_default_thread = LiftThread(default_dist)
                self.lift_default_thread.start()
                self.lift_default_thread.trigger.connect(self.btn_able)
        else:
            print("设置页面未支持命令")

    # 滴定页面控制命令
    def Measure_Control(self):
        global current_pump, start_measure_time, end_measure_time
        sender_PH = self.sender().objectName()
        index_PH = {
            "Btn_MeasureBegin": 0,
            "Btn_MeasureStop": 1,
        }
        PH_flag = index_PH[sender_PH]
        if PH_flag == 0:
            if(self.TestPump.lcdNumber.value()==0):
                acidpump.stop()
                alkalipump.stop()
                testpump.stop()
                self.PH_timer.stop()
                self.PH_measure_timer.stop()
                self.TitrationView.reset()
                self.TitrationViewStop.reset()
                self.timer1s.stop()
                self.test_msg_box.show()
                return
            self.TitratorStop.Lcd_CalibrationDosage.display(0)
            self.TitratorStop.Lcd_TestConcentration.display(0)
            self.TitratorStop.Btn_MeasureStop.setDisabled(False)
            print("开始滴定命令")
            self.PH_list.clear()
            start_measure_time = datetime.datetime.now()
            if(self.PH_timer.isActive() == False):
              self.PH_timer.start()
            self.timestamp = 0
            self.TitrationView.reset()
            self.TitrationViewStop.reset()
            self.timer1s.stop()
            self.timer1s.start(1000)
            #ph_meter.reset()
            ph = ph_meter.readPH(25)
            print("带滴定液体ph值：", ph)
            if ph < 7:
              print("使用碱泵滴定")
              current_pump = alkalipump
              self.AlkaliPump.speed = flowrate
            else:
              print("使用酸泵滴定")
              current_pump = acidpump
              self.AcidPump.speed = flowrate
            current_pump.set_speed(flowrate, current_pump.CW)
        elif PH_flag == 1:
            self.TitratorStop.Btn_MeasureStop.setDisabled(True)
            end_measure_time = datetime.datetime.now()
            if(self.PH_timer.isActive() == True):
                self.PH_timer.stop()
            print("停止滴定命令")

            acidpump.stop()
            alkalipump.stop()
            testpump.stop()

            print("self.TestPump.lcdNumber.value()=",self.TestPump.lcdNumber.value())
            print("self.TestPumpSetting.lcdNumber.value()=",self.TestPumpSetting.lcdNumber.value())
            #被测液用量
            test_liquide_volume = format(self.TestPump.lcdNumber.value(), '.1f')
            self.TitratorStop.Lcd_TestDosage.display(test_liquide_volume)

            # 被测溶液浓度
            if self.TestPumpSetting.lcdNumber.value():
                test_liquide_volume = self.TestPumpSetting.lcdNumber.value()
                print("setting test_liquide_volume", test_liquide_volume)

            if ('start_measure_time' in globals()) and ('end_measure_time' in globals()):
                calibration_time = end_measure_time - start_measure_time
                calibration_time = float(format(calibration_time.seconds * 0.143, '.3f'))
                if(self.TitratorStop.Lcd_TestConcentration.value() == 0):
                  if(float(test_liquide_volume) > 0):
                    if(current_pump==alkalipump):
                        value = (calibration_time*alkali_concentration/float(test_liquide_volume))*factor
                    else:
                        value = (calibration_time*acid_concentration/float(test_liquide_volume))/factor
                    if (value <= 0):
                        self.TitratorStop.Lcd_TestConcentration.display(0)
                    else:
                        value = format(value, '.3f')
                        self.TitratorStop.Lcd_TestConcentration.display(value)
                  else:
                      self.TitratorStop.Lcd_TestConcentration.display("----------")
            else:
                self.TitratorStop.Lcd_TestConcentration.display("--------")

            # 标定液用量
            if('start_measure_time' in globals())and('end_measure_time' in globals()):
                if self.TitratorStop.Lcd_CalibrationDosage.value() == 0:
                  calibration_time = end_measure_time - start_measure_time
                  calibration_time = format(calibration_time.seconds*0.143, '.1f')
                  self.TitratorStop.Lcd_CalibrationDosage.display(calibration_time)
            else:
                self.TitratorStop.Lcd_CalibrationDosage.display(0)
            # 标定液浓度
            if(current_pump==alkalipump):
                alkali_concentration_value = format(alkali_concentration,'.3f')
                self.TitratorStop.Lcd_CalibrationConcentration.display(alkali_concentration_value)
            else:
                acid_concentration_value = format(acid_concentration, '.3f')
                self.TitratorStop.Lcd_CalibrationConcentration.display(acid_concentration_value)
            # 滴定终点
            self.TitratorStop.Lcd_TitratorEnd.display(str(target_ph))

        else:
            print("滴定页面未支持命令")

    def jumpPHCalibrationSecond(self):
        print("jumpPHCalibrationSecond")
        self.qsl_content.setCurrentIndex(16)
        self.timer.timeout.disconnect()
        self.timer.stop()

    def jumpPHCalibrationThird(self):
        print("jumpPHCalibrationThird")
        self.qsl_content.setCurrentIndex(2)
        self.timer.timeout.disconnect()
        self.timer.stop()

    # PH测量控制命令
    def PH_Control(self):
        sender_PH = self.sender().objectName()
        index_PH = {
            "Btn_PHBegin": 0,
            "Btn_PHCaliBeginFirst": 1,
            "Btn_PHCaliBeginSecond": 2,
            "Btn_PHCaliStop": 3,
            "Btn_PHCaliRestart": 4,
        }
        PH_flag = index_PH[sender_PH]
        if PH_flag == 0:
            print("PH开始测量命令")
            print("Btn_PHBegin.isChecked()=",self.PHMeasureContent.Btn_PHBegin.isChecked())
            self.PH_list.clear()
            if self.PHMeasureContent.Btn_PHBegin.isChecked():
              self.PH_measure_timer.start()
            elif self.PH_measure_timer.isActive():
              self.PH_measure_timer.stop()
            #self.PHMeasureContent.Btn_PHBegin.setEnabled(False)

        elif PH_flag == 1:
            if(self.PH_measure_timer.isActive() == True):
                self.PH_measure_timer.stop()
            print("Btn_PHBegin.isChecked()=",self.PHMeasureContent.Btn_PHBegin.isChecked())
            self.PHMeasureContent.Btn_PHBegin.setEnabled(True)
            print("PH校准第一步命令")
            # 显示勾
            ph_meter.calibration(ph=4)
            self.PHCalibrationFirst.Btn_OK.setHidden(False)
            # 跳转到校准第二步页面
            self.timer.timeout.connect(self.jumpPHCalibrationSecond)
            self.timer.start(1000)
        elif PH_flag == 2:
            if(self.PH_measure_timer.isActive() == True):
                self.PH_measure_timer.stop()
            self.PHMeasureContent.Btn_PHBegin.setEnabled(True)
            print("PH校准第二步命令")
            # 显示勾
            ph_meter.calibration(ph=7)
            self.PHCalibrationSecond.Btn_OK.setHidden(False)
            self.timer.timeout.connect(self.jumpPHCalibrationThird)
            self.timer.start(1000)
        elif PH_flag == 3:
            if(self.PH_measure_timer.isActive() == True):
                self.PH_measure_timer.stop()
            self.PHMeasureContent.Btn_PHBegin.setEnabled(True)
            print("PH校准完成命令")
        elif PH_flag == 4:
            if(self.PH_measure_timer.isActive() == True):
                self.PH_measure_timer.stop()
            self.PHMeasureContent.Btn_PHBegin.setEnabled(True)
            print("PH重新校准命令")
        else:
            print("PH测量未支持命令")

    # 酸泵控制命令
    def Acid_Pump_Control(self):
        sender_Acid_Pump = self.sender().objectName()
        index_Acid_Pump = {
            "Btn_Clean": 0,
            "Btn_AcidPumpAdd": 1,
            "Btn_AcidPumpReduce": 2
        }
        Acid_Pump_flag = index_Acid_Pump[sender_Acid_Pump]
        if Acid_Pump_flag == 0:
            print("酸泵清零命令")
            self.AcidPump.lcdNumber.display(0)
            self.AcidPumpSetting.lcdNumber.display(0)
            acidpump.set_speed(0,acidpump.CW)
            self.AcidPump.speed = 0
        elif Acid_Pump_flag == 1:
            print("酸泵给进命令 ", self.AcidPumpSetting.Btn_AcidPumpAdd.isDown())
            if self.AcidPump.speed == 0:
              if self.AcidPump.Btn_AcidPumpAdd.isDown() or self.AcidPumpSetting.Btn_AcidPumpAdd.isDown():
                acidpump.set_speed(flowrate,acidpump.CW)
                self.AcidPump.speed = flowrate
                if(self.factor_pump_acid<=0):
                    self.acidpump_feed_time.setInterval(700)
                else:
                    acidpump_interval = round(700/self.factor_pump_acid)
                    self.acidpump_feed_time.setInterval(acidpump_interval)
                self.acidpump_feed_time.start()
            else:
              acidpump.stop()
              self.AcidPump.speed = 0
              self.acidpump_feed_time.stop()
        elif Acid_Pump_flag == 2:
            print("酸泵给出命令", self.AcidPump.Btn_AcidPumpReduce.isDown())
            if self.AcidPump.speed == 0:
              if self.AcidPump.Btn_AcidPumpReduce.isDown() or self.AcidPumpSetting.Btn_AcidPumpReduce.isDown():
                acidpump.set_speed(flowrate,acidpump.CCW)
                self.AcidPump.speed = flowrate
            else:
              acidpump.stop()
              self.AcidPump.speed = 0
        else:
            print("酸泵校准未支持命令")


    # 酸泵校准控制命令
    def Acid_Pump_Calibration_Control(self):
        sender_Acid_Pump_Calibration = self.sender().objectName()
        index_Acid_Pump_Calibration = {
            "Btn_Clean": 0,
            "Btn_AcidPumpCalibrationAdd": 1,
            "Btn_AcidPumpCalibrationBegin": 2,
            "Btn_LiquidAdd1": 3,
            "Btn_LiquidReduce1": 4,
            "Btn_LiquidAdd01": 5,
            "Btn_LiquidReduce01": 6
        }
        Acid_Pump_Calibration_flag = index_Acid_Pump_Calibration[sender_Acid_Pump_Calibration]
        if Acid_Pump_Calibration_flag == 0:
            print("酸泵校准清零命令")
            self.AcidPumpCalibration.Btn_AcidPumpCalibrationAdd.setEnabled(True)
            self.AcidPumpCalibration.lcdNumber.display(0)
            acidpump.stop()
        elif Acid_Pump_Calibration_flag == 1:
            print("酸泵校准给进命令")
            self.AcidPumpCalibration.Btn_AcidPumpCalibrationAdd.setEnabled(False)
            self.AcidPumpCalibration.lcdNumber.display(15)
            self.pump_timer.start(6600*15)
            acidpump.set_speed(flowrate, testpump.CW)
        elif Acid_Pump_Calibration_flag == 2:
            value = self.AcidPumpCalibration.lcdNumber.value()
            if value !=0 :
                self.factor_pump_acid = round(15/value,2)
                self.calibration_msg_box.show()
            else:
                self.factor_pump_acid = -1
        elif Acid_Pump_Calibration_flag == 3:
            value = float(self.AcidPumpCalibration.lcdNumber.value())
            value = format(value+1, '.1f')
            self.AcidPumpCalibration.lcdNumber.display(value)
        elif Acid_Pump_Calibration_flag == 4:
            value = int(self.AcidPumpCalibration.lcdNumber.value())
            if((value-1)>0):
                value = format(value-1, '.1f')
                self.AcidPumpCalibration.lcdNumber.display(value)
        elif Acid_Pump_Calibration_flag == 5:
            value = float(self.AcidPumpCalibration.lcdNumber.value())
            value = format(value+0.1, '.1f')
            self.AcidPumpCalibration.lcdNumber.display(value)
        elif Acid_Pump_Calibration_flag == 6:
            value = float(self.AcidPumpCalibration.lcdNumber.value())
            if((value-0.1)>0):
                value = format(value-0.1, '.1f')
                self.AcidPumpCalibration.lcdNumber.display(value)
        else:
            print("酸泵校准未支持命令")

    # 碱泵控制命令
    def Alkali_Pump_Control(self):
        sender_Alkali_Pump = self.sender().objectName()
        index_Alkali_Pump = {
            "Btn_Clean": 0,
            "Btn_AlkaliPumpAdd": 1,
            "Btn_AlkaliPumpReduce": 2,
        }
        Alkali_Pump_flag = index_Alkali_Pump[sender_Alkali_Pump]
        if Alkali_Pump_flag == 0:
            print("碱泵清零命令")
            self.AlkaliPump.lcdNumber.display(0)
            self.AlkaliPumpSetting.lcdNumber.display(0)
            alkalipump.set_speed(0, alkalipump.CW)
            self.AlkaliPump.speed = 0
        elif Alkali_Pump_flag == 1:
            print("碱泵给进命令 ", self.AlkaliPump.Btn_AlkaliPumpAdd.isDown())
            if self.AlkaliPump.speed == 0:
              if self.AlkaliPump.Btn_AlkaliPumpAdd.isDown() or self.AlkaliPumpSetting.Btn_AlkaliPumpAdd.isDown():
                alkalipump.set_speed(flowrate, alkalipump.CW)
                self.AlkaliPump.speed = flowrate
                if(self.factor_pump_alkali<=0):
                    self.alkalipump_feed_time.setInterval(700)
                else:
                    alkalipump_interval = round(700/self.factor_pump_alkali)
                    self.alkalipump_feed_time.setInterval(alkalipump_interval)
                self.alkalipump_feed_time.start()
            else:
              alkalipump.stop()
              self.AlkaliPump.speed = 0
              self.alkalipump_feed_time.stop()
        elif Alkali_Pump_flag == 2:
            print("碱泵给出命令 ", self.AlkaliPump.Btn_AlkaliPumpReduce.isDown())
            if self.AlkaliPump.speed == 0:
              if self.AlkaliPump.Btn_AlkaliPumpReduce.isDown() or self.AlkaliPumpSetting.Btn_AlkaliPumpReduce.isDown():
                alkalipump.set_speed(flowrate, alkalipump.CCW)
                self.AlkaliPump.speed = flowrate
            else:
              alkalipump.stop()
              self.AlkaliPump.speed = 0
        else:
            print("碱泵校准未支持命令")


    # 碱泵校准控制命令
    def Alkali_Pump_Calibration_Control(self):
        sender_Alkali_Pump_Calibration = self.sender().objectName()
        index_Alkali_Pump_Calibration = {
            "Btn_Clean": 0,
            "Btn_AlkaliPumpCalibrationAdd": 1,
            "Btn_AlkaliPumpCalibrationBegin": 2,
            "Btn_LiquidAdd1": 3,
            "Btn_LiquidReduce1": 4,
            "Btn_LiquidAdd01": 5,
            "Btn_LiquidReduce01": 6
        }
        Alkali_Pump_Calibration_flag = index_Alkali_Pump_Calibration[sender_Alkali_Pump_Calibration]
        if Alkali_Pump_Calibration_flag == 0:
            print("碱泵校准清零命令")
            self.AlkaliPumpCalibration.Btn_AlkaliPumpCalibrationAdd.setEnabled(True)
            self.AcidPumpCalibration.lcdNumber.display(0)
            alkalipump.stop()
        elif Alkali_Pump_Calibration_flag == 1:
            print("碱泵校准给进命令")
            self.AlkaliPumpCalibration.Btn_AlkaliPumpCalibrationAdd.setEnabled(False)
            self.AlkaliPumpCalibration.lcdNumber.display(15)
            self.pump_timer.start(6600*15)
            alkalipump.set_speed(flowrate,testpump.CW)
        elif Alkali_Pump_Calibration_flag == 2:
            value = self.AlkaliPumpCalibration.lcdNumber.value()
            if value != 0:
                self.factor_pump_alkali = round(15/value,2)
                self.calibration_msg_box.show()
            else:
                self.factor_pump_alkali = -1
        elif Alkali_Pump_Calibration_flag == 3:
            value = float(self.AlkaliPumpCalibration.lcdNumber.value())
            value = format(value+1, '.1f')
            self.AlkaliPumpCalibration.lcdNumber.display(value)
        elif Alkali_Pump_Calibration_flag == 4:
            value = float(self.AlkaliPumpCalibration.lcdNumber.value())
            if((value-1)>0):
                value = format(value-1, '.1f')
                self.AlkaliPumpCalibration.lcdNumber.display(value)
        elif Alkali_Pump_Calibration_flag == 5:
            value = float(self.AlkaliPumpCalibration.lcdNumber.value())
            value = format(value+0.1, '.1f')
            self.AlkaliPumpCalibration.lcdNumber.display(value)
        elif Alkali_Pump_Calibration_flag == 6:
            value = float(self.AlkaliPumpCalibration.lcdNumber.value())
            if((value-0.1)>0):
                value = format(value-0.1, '.1f')
                self.AlkaliPumpCalibration.lcdNumber.display(value)
        else:
            print("碱泵校准未支持命令")


    # 待测液泵控制命令
    def test_Pump_Control(self):
        sender_test_Pump = self.sender().objectName()
        index_test_Pump = {
            "Btn_Clean": 0,
            "Btn_TestPumpAdd": 1,
            "Btn_TestPumpReduce": 2,
        }
        test_Pump_flag = index_test_Pump[sender_test_Pump]
        if test_Pump_flag == 0:
            print("待测液泵清零命令")
            self.TestPump.lcdNumber.display(0)
            self.TestPumpSetting.lcdNumber.display(0)
            testpump.set_speed(0, testpump.CW)
        elif test_Pump_flag == 1:
            print("待测液泵给进命令 speed=", self.TestPump.speed)
            if self.TestPump.speed == 0:
              if self.TestPump.Btn_TestPumpAdd.isDown() or self.TestPumpSetting.Btn_TestPumpAdd.isDown():
                testpump.set_speed(flowrate, testpump.CW)
                self.TestPump.speed = flowrate
                if(self.factor_pump_test<=0):
                   self.testpump_feed_time.setInterval(700)
                else:
                   testpump_interval = round(700/self.factor_pump_test)
                   self.testpump_feed_time.setInterval(testpump_interval)
                if(self.testpump_feed_time.isActive() == False):
                  self.testpump_feed_time.start()
            else:
              testpump.stop()
              self.TestPump.speed = 0
              self.testpump_feed_time.stop()
        elif test_Pump_flag == 2:
            print("待测液泵给出命令, speed=", self.TestPump.speed)
            if self.TestPump.speed == 0:
              if self.TestPump.Btn_TestPumpReduce.isDown() or self.TestPumpSetting.Btn_TestPumpReduce.isDown():
                testpump.set_speed(flowrate, testpump.CCW)
                self.TestPump.speed = flowrate
            else:
              testpump.stop()
              self.TestPump.speed == 0
        else:
            print("待测液泵校准未支持命令")


    # 待测液泵校准控制命令
    def test_Pump_Calibration_Control(self):
        sender_test_Pump_Calibration = self.sender().objectName()
        index_test_Pump_Calibration = {
            "Btn_Clean": 0,
            "Btn_TestPumpCalibrationAdd": 1,
            "Btn_TestPumpCalibrationBegin": 2,
            "Btn_LiquidAdd1": 3,
            "Btn_LiquidReduce1": 4,
            "Btn_LiquidAdd01": 5,
            "Btn_LiquidReduce01": 6
        }
        test_Pump_Calibration_flag = index_test_Pump_Calibration[sender_test_Pump_Calibration]
        if test_Pump_Calibration_flag == 0:
            print("待测液泵校准清零命令")
            self.TestPumpCalibration.Btn_TestPumpCalibrationAdd.setEnabled(True)
            self.TestPumpCalibration.lcdNumber.display(0)
            testpump.stop()
        elif test_Pump_Calibration_flag == 1:
            print("待测液泵校准给进命令")
            self.TestPumpCalibration.Btn_TestPumpCalibrationAdd.setEnabled(False)
            self.TestPumpCalibration.lcdNumber.display(15)
            self.pump_timer.start(6600*15) #正确的参数为6600*15
            testpump.set_speed(flowrate, testpump.CW)
        elif test_Pump_Calibration_flag == 2:
            value = self.TestPumpCalibration.lcdNumber.value()
            if value !=0 :
              self.factor_pump_test = round(15/value,2)
              self.calibration_msg_box.show()
            else:
              self.factor_pump_test = -1
            print("待测液泵校准开始命令 value = ", self.factor_pump_test)
        elif test_Pump_Calibration_flag == 3:
            value = float(self.TestPumpCalibration.lcdNumber.value())
            value = format(value+1, '.1f')
            self.TestPumpCalibration.lcdNumber.display(value)
        elif test_Pump_Calibration_flag == 4:
            value = float(self.TestPumpCalibration.lcdNumber.value())
            if((value-1)>0):
              value = format(value-1,'.1f')
              self.TestPumpCalibration.lcdNumber.display(value)
        elif test_Pump_Calibration_flag == 5:
            value = float(self.TestPumpCalibration.lcdNumber.value())
            value = format(value+0.1, '.1f')
            self.TestPumpCalibration.lcdNumber.display(value)
        elif test_Pump_Calibration_flag == 6:
            value = float(self.TestPumpCalibration.lcdNumber.value())
            if((value-0.1)>0):
              value = format(value-0.1, '.1f')
              self.TestPumpCalibration.lcdNumber.display(value)
        else:
            print("待测液泵校准未支持命令")

    # 升降平台控制命令
    def Lift_Control(self):
#        self.lift_timer.start(3000)
#        self.lift_timer.timeout.connect(self.lift_timeout)
        global dist, default_dist
        dist = urm.distance_cm()
        sender_Lift = self.sender().objectName()
        index_Lift = {
            "Btn_Clean": 0,
            "Btn_LiftAdd": 1,
            "Btn_LiftReduce": 2,
            "Btn_Up": 1,
            "Btn_Down": 2,
        }
        Lift_flag = index_Lift[sender_Lift]
        if Lift_flag == 0:
            print("升降平台回原位命令")
            self.Lift.Btn_LiftReduce.setEnabled(False)
            self.Lift.Btn_LiftAdd.setEnabled(False)
            self.Lift.Btn_Clean.setEnabled(False)
            self.Lift.Btn_ReturnManual.setEnabled(False)
            self.Lift.Btn_Home.setEnabled(False)
            self.LiftSetting.Btn_ReturnInitialization.setEnabled(False)
            self.LiftSetting.Btn_Home.setEnabled(False)
            self.LiftSetting.Btn_LiftAdd.setEnabled(False)
            self.LiftSetting.Btn_LiftReduce.setEnabled(False)
            self.LiftSetting.Btn_Clean.setEnabled(False)
            self.PHCalibrationFirst.Btn_Up.setEnabled(False)
            self.PHCalibrationFirst.Btn_Down.setEnabled(False)
            self.PHCalibrationSecond.Btn_Up.setEnabled(False)
            self.PHCalibrationSecond.Btn_Down.setEnabled(False)
            self.Lift.lcdNumber.display(default_dist)
            self.LiftSetting.lcdNumber.display(default_dist)
            self.lift_default_thread = LiftThread(default_dist)
            self.lift_default_thread.start()
            self.lift_default_thread.trigger.connect(self.btn_able)
        elif Lift_flag == 2:
            print("升降平台下降命令")
            if dist % 2:
              dist = dist - 1
            value = dist
            print()
            if value < 18:
              if not hasattr(self, "lift_down_thread"):
                self.Lift.Btn_LiftReduce.setEnabled(False)
                self.Lift.Btn_LiftAdd.setEnabled(False)
                self.LiftSetting.Btn_LiftAdd.setEnabled(False)
                self.LiftSetting.Btn_LiftReduce.setEnabled(False)
                self.Lift.Btn_Clean.setEnabled(False)
                self.LiftSetting.Btn_Clean.setEnabled(False)
                self.Lift.Btn_ReturnManual.setEnabled(False)
                self.Lift.Btn_Home.setEnabled(False)
                self.LiftSetting.Btn_ReturnInitialization.setEnabled(False)
                self.LiftSetting.Btn_Home.setEnabled(False)
                self.PHCalibrationFirst.Btn_Up.setEnabled(False)
                self.PHCalibrationFirst.Btn_Down.setEnabled(False)
                self.PHCalibrationSecond.Btn_Up.setEnabled(False)
                self.PHCalibrationSecond.Btn_Down.setEnabled(False)
                print("new lift_down_thread")
                self.lift_down_thread = LiftThread(value+2)
                self.lift_down_thread.start()
                self.lift_down_thread.trigger.connect(self.btn_able)
                self.Lift.lcdNumber.display(((value + 2)//2)*2)
                self.LiftSetting.lcdNumber.display(((value + 2)//2)*2)
        elif Lift_flag == 1:
            print("升降平台上升命令")
            if dist % 2:
              dist = dist + 1
            value = dist
            if value > 3:
              if not hasattr(self, "lift_up_thread"):
                self.Lift.Btn_LiftReduce.setEnabled(False)
                self.Lift.Btn_LiftAdd.setEnabled(False)
                self.LiftSetting.Btn_LiftAdd.setEnabled(False)
                self.LiftSetting.Btn_LiftReduce.setEnabled(False)
                self.Lift.Btn_Clean.setEnabled(False)
                self.LiftSetting.Btn_Clean.setEnabled(False)
                self.Lift.Btn_ReturnManual.setEnabled(False)
                self.Lift.Btn_Home.setEnabled(False)
                self.LiftSetting.Btn_ReturnInitialization.setEnabled(False)
                self.LiftSetting.Btn_Home.setEnabled(False)
                self.PHCalibrationFirst.Btn_Up.setEnabled(False)
                self.PHCalibrationFirst.Btn_Down.setEnabled(False)
                self.PHCalibrationSecond.Btn_Up.setEnabled(False)
                self.PHCalibrationSecond.Btn_Down.setEnabled(False)
                print("new lift_up_thread")
                self.lift_up_thread = LiftThread(value-2)
                self.lift_up_thread.start()
                self.lift_up_thread.trigger.connect(self.btn_able)
                self.Lift.lcdNumber.display(((value - 2)//2)*2)
                self.LiftSetting.lcdNumber.display(((value + 2)//2)*2)
        else:
            print("升降平台未支持命令")


    def btn_able(self):
       if hasattr(self, "lift_default_thread"):
           print("beore del lift_default_thread")
           self.lift_default_thread.quit()
           del self.lift_default_thread
           print("after del lift_default_thread")
       if hasattr(self, "lift_down_thread"):
           print("before del lift_down_thread")
           self.lift_down_thread.quit()
           del self.lift_down_thread
           print("after del lift_down_thread")
       if hasattr(self, "lift_up_thread"):
           print("before del lift_down_thread")
           self.lift_up_thread.quit()
           del self.lift_up_thread
           print("after del lift_down_thread")

       self.Lift.Btn_LiftReduce.setEnabled(True)
       self.Lift.Btn_LiftAdd.setEnabled(True)
       self.Lift.Btn_Clean.setEnabled(True)
       self.LiftSetting.Btn_LiftAdd.setEnabled(True)
       self.LiftSetting.Btn_LiftReduce.setEnabled(True)
       self.LiftSetting.Btn_Clean.setEnabled(True)
       self.Lift.Btn_ReturnManual.setEnabled(True)
       self.Lift.Btn_Home.setEnabled(True)
       self.LiftSetting.Btn_ReturnInitialization.setEnabled(True)
       self.LiftSetting.Btn_Home.setEnabled(True)
       self.PHCalibrationFirst.Btn_Up.setEnabled(True)
       self.PHCalibrationFirst.Btn_Down.setEnabled(True)
       self.PHCalibrationSecond.Btn_Up.setEnabled(True)
       self.PHCalibrationSecond.Btn_Down.setEnabled(True)
       self.lift_timer.stop()

    def eventFilter(self, obj, event):
        if event.type() == QEvent.MouseButtonPress:
            # mouseEvent = QMouseEvent(event)
            # 当检测到事件源来自于触摸自动转换为鼠标事件时,则对该事件不处理
            if event.source() == 1:
                return True
        elif event.type() == QEvent.MouseButtonRelease:
            # 当检测到事件源来自于触摸自动转换为鼠标事件时,则对该事件不处理
            if event.source() == 1:
                return True
        elif event.type() == QEvent.TouchBegin:
            touchPoints = event.touchPoints()
            for point in touchPoints:
                # 伪造一个鼠标事件,当TouchBegin时发送一个伪造好的鼠标左键按下的事件
                wx_mouseEvent = QMouseEvent(QEvent.MouseButtonPress, point.lastPos(), Qt.MouseButton.LeftButton,
                                            Qt.MouseButton.LeftButton, Qt.NoModifier)
                QApplication.sendEvent(obj, wx_mouseEvent)
        elif event.type() == QEvent.TouchEnd:
            touchPoints = event.touchPoints()
            for point in touchPoints:
                # 伪造一个鼠标事件,当TouchEnd时发送一个伪造好的鼠标左键松开的事件
                wx_mouseEvent = QMouseEvent(QEvent.MouseButtonRelease, point.lastPos(), Qt.MouseButton.LeftButton,
                                            Qt.MouseButton.LeftButton, Qt.NoModifier)
                QApplication.sendEvent(obj, wx_mouseEvent)
        return QWidget.eventFilter(self, obj, event)

    def closeEvent(self,event):
        leo.disconnect()
        acidpump.stop()
        alkalipump.stop()
        testpump.stop()
        pwm0.write_digital(0)
        pwm1.write_digital(0)

if __name__ == '__main__':
    cwdpath, _ = os.path.split(os.path.realpath(__file__))
    os.chdir(cwdpath)
    ph_meter.begin()
    App = QApplication(sys.argv)  # 创建QApplication对象，作为GUI主程序入口
    min = Min()
    min.showFullScreen()
    App.installEventFilter(min)
    min.show()
    sys.exit(App.exec_())  # 循环中等待退出程序

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
