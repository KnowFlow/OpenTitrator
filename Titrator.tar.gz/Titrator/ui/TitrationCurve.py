import sys
import random
from PyQt5.QtChart import QDateTimeAxis, QValueAxis, QSplineSeries, QChart, QChartView
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QPainter
from PyQt5.QtCore import QDateTime, Qt, QTimer


class ChartView(QChartView, QChart):
    def __init__(self, *args, **kwargs):
        super(ChartView, self).__init__(*args, **kwargs)
        self.timer = QTimer(self)
        self.chart = QChart()
        self.series = QSplineSeries()
        self.resize(800, 600)
        self.setRenderHint(QPainter.Antialiasing)  # 抗锯齿
        self.chart_init()

    def chart_init(self):
        # 设置曲线名称
        self.series.setName("滴定曲线")
        # 把曲线添加到QChart的实例中
        self.chart.addSeries(self.series)
        # 声明并初始化X轴，Y轴
        self.dtaxisX = QValueAxis()
        self.vlaxisY = QValueAxis()
        # 设置坐标轴显示范围
        self.dtaxisX.setMin(0)#QDateTime.currentDateTime().addSecs(-300 * 1))
        self.dtaxisX.setMax(20)#QDateTime.currentDateTime().addSecs(0))
        self.max = 20
        self.vlaxisY.setMin(0)
        self.vlaxisY.setMax(14)
        # 设置X轴时间样式
        #self.dtaxisX.setFormat("ss")
        # 设置坐标轴上的格点
        self.dtaxisX.setTickCount(11+10)
        self.vlaxisY.setTickCount(15)
        # 设置坐标轴名称
        self.dtaxisX.setTitleText("ML")
        self.vlaxisY.setTitleText("PH")
        # 设置网格不显示
        self.vlaxisY.setGridLineVisible(True)
        # 把坐标轴添加到chart中
        self.chart.addAxis(self.dtaxisX, Qt.AlignBottom)
        self.chart.addAxis(self.vlaxisY, Qt.AlignLeft)
        # 把曲线关联到坐标轴
        self.series.attachAxis(self.dtaxisX)
        self.series.attachAxis(self.vlaxisY)

        self.setChart(self.chart)
    '''
    def drawLine(self, value):
        # 获取当前时间
        bjtime = QDateTime.currentDateTime()
        # 更新X轴坐标
        self.dtaxisX.setMin(QDateTime.currentDateTime().addSecs(-300 * 1))
        self.dtaxisX.setMax(QDateTime.currentDateTime().addSecs(0))
        # 当曲线上的点超出X轴的范围时，移除最早的点
        if self.series.count() > 149:
            self.series.removePoints(0, self.series.count() - 149)
        # 添加数据到曲线末端
        self.series.append(bjtime.toMSecsSinceEpoch(), value)
    '''

    def reset(self):
        self.dtaxisX.setMin(0)
        self.dtaxisX.setMax(20)
        self.series.clear()
        #self.series.removePoints(0, self.series.count())
        
    def drawLine(self, timestamp, value):
        # 获取当前时间
        #now = QDateTime.currentDateTime()
        # 更新X轴坐标
        if timestamp*0.16 > self.max:
            self.max = self.max + 1
            self.dtaxisX.setMin(self.max - 20)
            self.dtaxisX.setMax(self.max)
            while self.series.at(0).x() < self.max-20:
                self.series.removePoints(0, 1)
        # 添加数据到曲线末端
        print("append(%.2f,%.2f)"%(timestamp*0.16, value))
        self.series.append(timestamp*0.16, value) #0.16表示每秒0.16ml